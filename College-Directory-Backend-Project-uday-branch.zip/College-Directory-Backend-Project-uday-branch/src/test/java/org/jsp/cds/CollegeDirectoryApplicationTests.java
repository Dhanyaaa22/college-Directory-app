package org.jsp.cds;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CollegeDirectoryApplicationTests {

	@Test
	void contextLoads() {
	}

}

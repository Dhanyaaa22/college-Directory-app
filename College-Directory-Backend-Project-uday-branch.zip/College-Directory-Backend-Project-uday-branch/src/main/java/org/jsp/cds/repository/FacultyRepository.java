package org.jsp.cds.repository;

import org.jsp.cds.entity.Faculty;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FacultyRepository extends JpaRepository<Faculty, Long > {
}

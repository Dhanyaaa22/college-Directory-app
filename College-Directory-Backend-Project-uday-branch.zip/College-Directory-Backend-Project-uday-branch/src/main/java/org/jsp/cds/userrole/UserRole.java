package org.jsp.cds.userrole;



public enum UserRole {
    STUDENT,
    FACULTY,
    ADMIN
}